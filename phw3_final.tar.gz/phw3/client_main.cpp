#include "ClientUtility.hpp"

using namespace std;
int main(int argc, char *argv[])
{
    int error = 7890; int num_bytes;
    
    char *buf = (char *)malloc( (3000)*sizeof(char) );  // shared buf block
    connection_info server_conn_info;
    Utility::initialize_server(argc, argv, server_conn_info);
    // preparing GET request
    char * query = Utility::get_http_request( argv[3] );
    
    cout << "CIENT: GET " << argv[3] << endl;
    if ((error = send(server_conn_info.sockfd, query, strlen(query),0) )  == -1){
        perror("CLIENT: send");
    }
    
    ofstream requested_file;
    char *filename = Utility::get_filename(argv[3]);
    stringstream ss;
    ss << filename;
    
    requested_file.open(ss.str().c_str(), ios::out | ios::binary);
    
    if (!requested_file.is_open()){
        cout << "Could not created file in file system" << endl;
        exit(0);
    }
    
    bool content = false;
    bool first = true;
    int i = 0;
    while (true) {
        //num_bytes = recv(server_conn_info.sockfd, buf, 2000, 0); // receive message from server
        i = 0;
        num_bytes = recv(server_conn_info.sockfd, buf, 2000, 0);
        // printf("%d\n",num_bytes);
        if (first) {
            stringstream tmp;
            tmp << buf;
            string line;
            getline(tmp, line);
            if (line.find("404") != string::npos)
                cout << "SERVER: **ERROR** " << line << endl;
            else
                cout << "SERVER: " << line << endl;
            first = false;
        }
        if (!content) {
            i = Utility::start_of_content(buf, num_bytes);
            if (i >3){
                cout << "CLIENT: found start of content in this packet at pos: " << i << endl;
                content = true;
            } else if (i == -1){
                cout << "CLIENT: The received file might be invalid, abort receiving!" << endl;
                close(server_conn_info.sockfd);
                requested_file.flush();
                requested_file.close();
                break;
            }
        }
        requested_file.write(buf + i, num_bytes - i); // Store received data in file
        if (num_bytes == -1) {
            perror("client: recv");
        } else if (num_bytes == 0) { // if number of bytes received is zero, it means server has closed the connection
            close(server_conn_info.sockfd);
            cout << "CLIENT: File Saved at: " << filename
                 << endl; // Close the connection when server closes the connection
            printf("CLIENT: Connection closed by server\n");
            requested_file.flush();
            requested_file.close();
            break;
        }
        else{
            requested_file.flush(); // Flush the output file buffers       
        } 
    } // end of while(true)
    requested_file.close(); // Close the output file
    return 0;
}
