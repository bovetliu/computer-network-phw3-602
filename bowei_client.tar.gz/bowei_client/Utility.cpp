#include "Utility.hpp"

Utility::Utility()
{
}

Utility::~Utility()
{
}

