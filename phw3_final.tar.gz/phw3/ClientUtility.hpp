#ifndef CLIENT_UTILITY_HPP
#define CLIENT_UTILITY_HPP

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>  // close (file_descriptor) needs this
#include <fcntl.h>
#include <cstring> //  memcpy({3}) need this
#include <arpa/inet.h>
#include <netinet/in.h>  
// above header is important, most networking programming stucts and MACRO constants such as INET_ADDRSTRLEN are defined within it

#include <iostream>
#include <stdio.h>
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <sys/wait.h>
#include <signal.h>
#include <cstdlib>
#include <ctime>

using namespace std;

typedef struct
{
    int sockfd;
    struct sockaddr_in address;
    struct addrinfo  address_info;

} connection_info;

struct web_file_info {
    char file[1024];
    char host[1024];
};

class Utility
{
public:
    Utility();
    ~Utility();
    
    struct sockaddr_storage client_addr;
    /*
    ** from Beej
    ** packi16() -- store a 16-bit int into a char buffer (like htons())
    */
    static void packi16(char *buf, unsigned short int i)
    {
        // for example i = 0x34d6
        // buffer[0] = 34   buffer[1] = d6
        // Big Endian
        *buf++ = i>>8;
        *buf++ = i;
    }

    // copied from team8 homework2
    static uint16_t unpacki16(char *buf)     //change  network byte order to the host order (16bit)
    {
        uint16_t i;
        memcpy(&i,buf,2);  // require <cstring>
        i = ntohs(i);
        return i;
    }
    
    
    // used code from Kan Zheng, our group member
    static int connect_to_web(char* ipaddr,char* port)
    {
        int sockfd;
        int rv;
        struct addrinfo hints, *servinfo, *p;
        memset(&hints, 0, sizeof hints);
        hints.ai_family = AF_UNSPEC;
        hints.ai_socktype = SOCK_STREAM;
        if ((rv = getaddrinfo(ipaddr, port, &hints, &servinfo)) != 0) {
            fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
            return -1;
        }
        // loop through all the results and connect to the first we can
        for(p = servinfo; p != NULL; p = p->ai_next) {
            if ((sockfd = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1) {
                perror("client: socket");
                continue;
            }
            if (connect(sockfd, p->ai_addr, p->ai_addrlen) == -1) {
                close(sockfd);
                perror("client: connect");
                continue;
            }       
            break;
        }
        if (p == NULL) {
            fprintf(stderr, "client: failed to connect\n");
            return -1;
        }
        freeaddrinfo(servinfo); // all done with this structure
        return sockfd;
    }

    static string castNumberToString( int number){
        stringstream temp_sstream;
        temp_sstream << number;
        return temp_sstream.str();
    }

    // the purpose of this function is get valid socket file descriptor
    // return 0, means it is functioning properly
    static int initialize_server( int argc, char* argv[], connection_info& server_info)
    {
        int sockfd;
        if (argc != 4)
        {
            printf ("usage: ./client <ip> <port> <The page URL> \n");
            return 1;
        }
        struct addrinfo hints, *servinfo, *p;
        int status = -1;
        int error;
        memset(&hints, 0, sizeof hints);
        hints.ai_family = AF_INET;
        hints.ai_socktype = SOCK_STREAM;
        //hints.ai_flags = AI_PASSIVE;   // use my own ip address
        if ( (status = getaddrinfo(argv[1], argv[2], &hints, &servinfo ) ) != 0 )
        {
            fprintf( stderr, "getaddrinfo: %s\n", gai_strerror(status));
            return 1;
        }
        // servinfo now points to result linked list
        for (p = servinfo; p != NULL; p = p -> ai_next )
        {
            if ( (sockfd = socket(p -> ai_family, p-> ai_socktype, p->ai_protocol) ) == -1)
            {
                perror("unable to get socket");
                continue;
            }
            // no error happened to this *sockfd, which means it is a valid one.
            break;
        }
        if (p == NULL)
        {
            fprintf(stderr, "listerner: failed to connect sockets\n");
            return 2;
        }
        // From Page 24 of Beej's Book
        int yes = 1;
        if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes)) == -1) {
            perror("setsockopt");
            exit(1);
        }
        
        if ( (error = connect(sockfd, p->ai_addr, p->ai_addrlen)) == -1){
            perror("Client: cannot connect");
        }
        // Connected 
        freeaddrinfo(servinfo);
        
        //starting to fill container arguemnts
        server_info.sockfd = sockfd;
        server_info.address = *( (struct sockaddr_in *) p->ai_addr);
        server_info.address_info = *p;
        printf("Client: connected to server \n");
        return 0;
    }

    // from page 36 of beej
    // get pointer of sin_addr or sin6_addr , IPv4 or IPv6:
    static void *get_in_addr(struct sockaddr *sa)
    {
        if (sa->sa_family == AF_INET)
        {
            return &(((struct sockaddr_in*)sa)->sin_addr);
        }
        return &(((struct sockaddr_in6*)sa)->sin6_addr);
    }
    
    // I will change this later
    // get the file name for storing requested data
    static char *get_filename(char *url){
        string url_str(url);
        size_t found = url_str.find_last_of('/');
        string indexhtml("index.html");
        char *cstr_output = (char *)malloc((100)*sizeof(char));
        if (found > 6 && found == url_str.length()-1){
            strncpy(cstr_output, indexhtml.c_str(), indexhtml.length()+1);
            return cstr_output;
        }
        indexhtml = url_str.substr(found+1);
        strncpy(cstr_output, indexhtml.c_str(), indexhtml.length()+1);
        return cstr_output;
    }
    
    // generate a HTTP GET Request for given URL
    static char *get_http_request(char *url){
        string output;
        string url_str(url);
        string page;
        char *cstr_output = (char *)malloc((300)*sizeof(char));
        if (url_str.compare(0,7, "http://") != 0 ){
            cout <<"CLIENT: " << url << "is not a http request" << endl;
            strncpy(cstr_output, output.c_str(), output.length()+1);
            return cstr_output;  //  
        }
        size_t found = url_str.find_first_of('/', 7);
        if (found == string::npos){
            cout << "CLIENT: " << url << "did not find closing '/'" << endl;
            page = "/";
        }
        else{
            page = url_str.substr(found);
        }
        string host = url_str.substr(7,found-7);
        output = "GET " + page + " HTTP/1.0\r\n" + "Host: " + host +"\r\n\r\n";
        strncpy(cstr_output, output.c_str(), output.length()+1);
        return cstr_output;  // 
    }
    
    static int start_of_content( char * buf, int num_bytes ){
        int pos = -1;  // -1 means cannot find \r\n\r\n in the content pointed by buf
        if (num_bytes < 4)  return pos;
        pos = 3;
        for (pos = 3; pos < num_bytes; pos++) {
            if (buf[pos-3] == '\r' && buf[pos - 2] == '\n' && buf[pos - 1] == '\r' && buf[pos] == '\n') {
                pos++;
                return pos;
            }
        }
        return 0;
    }
};

#endif // CLIENT_UTILITY_HPP
