#include "ClientUtility.hpp"

Utility::Utility()
{
}

Utility::~Utility()
{
}

