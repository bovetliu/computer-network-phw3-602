#include "ProxyUtility.hpp"

Utility::Utility()
{
}

Utility::~Utility()
{
}

